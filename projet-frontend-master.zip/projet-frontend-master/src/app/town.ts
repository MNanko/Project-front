export class Town {
  id: number;
  name: string;
  icon: string;
  temperature: number;
}
